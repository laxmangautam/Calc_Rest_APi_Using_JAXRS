package com.laxman.calc.rest.api.model;



import com.laxman.calc.rest.api.service.Constant;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Response {

	private boolean isSuccess;
	private String message;
	private Long calculatedValue;

	public Response () {
		this.isSuccess = true;
		this.message = Constant.SUCCESS;
		this.calculatedValue = 0L;

	}
	public Response (Boolean status , String message , Long result) {
		this.isSuccess = status;
		this.message = message;
		this.calculatedValue = result;

	}

	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Long getCalculatedValue() {
		return calculatedValue;
	}

	public void setCalculatedValue(Long result) {
		this.calculatedValue = result;
	}



}