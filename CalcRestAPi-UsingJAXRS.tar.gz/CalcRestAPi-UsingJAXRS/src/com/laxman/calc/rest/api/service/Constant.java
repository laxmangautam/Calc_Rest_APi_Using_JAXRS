package com.laxman.calc.rest.api.service;

public class Constant {

    public static final String SUCCESS = "SUCCESS";
    public static final String FAIL = "FAIL";
}
