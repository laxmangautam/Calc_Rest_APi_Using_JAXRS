package com.laxman.calc.rest.api.service;


import com.laxman.calc.rest.api.model.Response;
import com.laxman.calc.rest.api.model.request.CalculatorServiceRequest;


public interface CalcService {

	Response adderAndSubtractor( CalculatorServiceRequest requst);
	
	Response multiplier( CalculatorServiceRequest requst);


}