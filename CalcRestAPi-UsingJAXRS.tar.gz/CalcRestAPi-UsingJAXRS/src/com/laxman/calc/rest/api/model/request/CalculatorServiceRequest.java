package com.laxman.calc.rest.api.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.laxman.calc.rest.api.service.ServiceUtil;
import org.codehaus.jackson.map.ObjectMapper;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "requestObject",
        "signatureToAuthenticate"
})
@XmlRootElement
public class CalculatorServiceRequest {
    private String apiVersion;
    private String invokingParty;
    List<Long> inputOperand = new ArrayList<Long>();
    private String signatureToAuthenticate;

    public String getApiVersion() {
        return apiVersion;
    }

    public String getInvokingParty() {
        return invokingParty;
    }


    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }

    public void setInvokingParty(String invokingParty) {
        this.invokingParty = invokingParty;
    }

    public List<Long> getInputOperand() {
        return inputOperand;
    }

    public void setInputOperand(List<Long> inputOperand) {
        this.inputOperand = inputOperand;
    }


    public String getSignatureToAuthenticate() {
        return signatureToAuthenticate;
    }



    public void setSignatureToAuthenticate(String signatureToAuthenticate) {
        this.signatureToAuthenticate = signatureToAuthenticate;
    }


    public static void main (String[] a) throws IOException {
        CalculatorServiceRequest calculatorServiceRequest = new CalculatorServiceRequest();
        calculatorServiceRequest.setApiVersion("JAVA-1.0.0.2019032");
        calculatorServiceRequest.setInvokingParty("CentralGroup-09123");

        List <Long > inputOperand = new ArrayList<>();
        inputOperand.add(44L);
        inputOperand.add(54L);
        inputOperand.add(644L);
        inputOperand.add(-77L);
        inputOperand.add(4L);
        calculatorServiceRequest.setInputOperand(inputOperand);
        calculatorServiceRequest.setSignatureToAuthenticate("Test Signature");
        ObjectMapper mapper = new ObjectMapper();
        String jsonInString = mapper.writeValueAsString(calculatorServiceRequest);
        System.out.println(jsonInString);
        System.out.println( ServiceUtil.generateSignature(calculatorServiceRequest));


    }
}