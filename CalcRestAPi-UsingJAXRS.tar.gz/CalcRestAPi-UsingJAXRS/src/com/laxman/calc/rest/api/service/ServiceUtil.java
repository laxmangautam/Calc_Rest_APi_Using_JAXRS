package com.laxman.calc.rest.api.service;

import com.laxman.calc.rest.api.model.Response;
import com.laxman.calc.rest.api.model.request.CalculatorServiceRequest;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.apache.commons.lang3.StringUtils;

public class ServiceUtil {

    // Every client will have separate secret key. Assumption we will be using same key for now. We can pass it from configuration.
    private static String secretKey = "f06be9ad0a0e4678bd892ed97c34afe8";

    public static boolean verifyMessageSignature(CalculatorServiceRequest notifyReq, StringBuffer logMsg){

        String  messageSignatureCreated;
        try {
            messageSignatureCreated  = MD5(new StringBuilder(notifyReq.getInvokingParty()).append(secretKey).toString());
            logMsg.append("Signature-To-Authenticate-Created ").append(messageSignatureCreated).append("\nSignature To Authenticate ").append(notifyReq.getSignatureToAuthenticate());
            if (StringUtils.isNotBlank(messageSignatureCreated) && StringUtils.equals(notifyReq.getSignatureToAuthenticate(), messageSignatureCreated)) {
                return true;
            }

        } catch (NoSuchAlgorithmException e) {
            logMsg.append("Error due to : ").append(e.getMessage());
            return false;
        }
        return false;

    }

    public static String  generateSignature(CalculatorServiceRequest notifyReq){

       try {
            return MD5(new StringBuilder(notifyReq.getInvokingParty()).append(secretKey).toString());

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }

    }

    public static String MD5(String text) throws NoSuchAlgorithmException {
        if (null != text) {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(text.getBytes(), 0, text.length());
            byte byteData[] = md.digest();
            StringBuilder hexString = new StringBuilder();

            for (int i = 0; i < byteData.length; i++) {
                String hex = Integer.toHexString(0xff & byteData[i]);
                if (hex.length() == 1)
                    hexString.append('0');
                hexString.append(hex);
            }

            return hexString.toString();
        }

        return null;
    }


    public static Response getErrorResponse (String message) {
        return new Response(false, message,0L);
    }


}
