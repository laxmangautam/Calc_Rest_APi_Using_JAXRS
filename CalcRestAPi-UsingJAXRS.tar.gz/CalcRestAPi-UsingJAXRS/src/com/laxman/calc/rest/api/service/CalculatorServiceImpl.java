package com.laxman.calc.rest.api.service;

import com.laxman.calc.rest.api.model.Response;
import com.laxman.calc.rest.api.model.request.CalculatorServiceRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.math.BigInteger;
import java.util.List;

/**
 * @author lgatuam
 */
@Path("/api")
public class CalculatorServiceImpl implements CalcService {

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getTestService() {
        return "Calculator-Service-Running";
    }

    @Override
    @Path("/addOrSubstract")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @POST
    public Response adderAndSubtractor(CalculatorServiceRequest request) {
        if (null != request.getInputOperand() && request.getInputOperand().size()>0) {
            if (ServiceUtil.verifyMessageSignature(request, new StringBuffer())) {
                return new Response(Boolean.TRUE.booleanValue(), Constant.SUCCESS, getResult(request.getInputOperand()));
            }
            else {
                return ServiceUtil.getErrorResponse("Invalid Signature ");
            }
        }
        return ServiceUtil.getErrorResponse("InputOperand size is Zero..");
    }

    @Override
    @Path("/multiplier")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @POST
    public Response multiplier(CalculatorServiceRequest request) {
        if (null != request.getInputOperand() && request.getInputOperand().size()>0) {
            if (ServiceUtil.verifyMessageSignature(request, new StringBuffer())) {
                return new Response(Boolean.TRUE.booleanValue(), Constant.SUCCESS, getMulipleResult(request.getInputOperand()));
            }
            else {
                return ServiceUtil.getErrorResponse("Invalid Signature ");
            }
        }
        return ServiceUtil.getErrorResponse("InputOperand size is Zero..");

    }


    public Long getResult (List <Long> inputNumber) {

        return inputNumber.stream().mapToLong(i -> i).sum();
    }

    public Long getMulipleResult (List <Long> inputNumber) {
        return inputNumber.stream().map(BigInteger::valueOf).reduce(BigInteger.ONE, BigInteger::multiply).longValue();
    }



}